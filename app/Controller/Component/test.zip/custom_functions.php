<?php

class CustomFunctionsComponent extends Object {

    function initialize(&$controller) 
    {        // saving the controller reference for later use        
            $this->controller =& $controller;    
    }
	 function checkAltUserId($intAuthId)
	{

	 	$intUserId = $GLOBALS['_COOKIE']['intUserId'];
		if($intUserId!='')
			return($intUserId);
		else
			return($intAuthId);
	}
	 function checkAltUserRoll($strAuthRoll)
	{

	 	$strUserRoll = $GLOBALS['_COOKIE']['strUserRoll'];
		if($strUserRoll!='')
			return($strUserRoll);
		else
			return($strAuthRoll);
	}
function checkGETValueForNull($strGetVal="",$strKeyName="")
     {
		
		if($strKeyName)
         {

			if($strKeyName == "intAdminId" || $strKeyName == "intBookId" ||$strKeyName=="strLoggedInUserName"|| $strKeyName == "intSourceId"||$strKeyName=="strEntityIds"||$strKeyName=="arrTripIds")
			{
				$strGetVal = $this->controller->Session->read($strKeyName);
			}
             if(!$strGetVal)
             {
                 if(isset($this->controller->params["form"][$strKeyName]))
                    $strGetVal = @$this->controller->params["form"][$strKeyName];
                 elseif(isset($this->controller->params["named"][$strKeyName]))
                    $strGetVal = @$this->controller->params["named"][$strKeyName];                  
                 else
                    $strGetVal = @$this->controller->params[$strKeyName];                  
             }
         }
         
         $strGetVal = ($strGetVal=="NULL")?"":$strGetVal;
         return($strGetVal);
     }
     
      // grab possible SET/ENUM values and return an array
        function getPossibleEnumValuesArray(&$objDBObject,$field)
        {           
        
            $query = "SHOW COLUMNS FROM ".$objDBObject->table." LIKE '$field'";
            $arrResultRecord = $objDBObject->query($query);
			if(isset($arrResultRecord[0]['COLUMNS']["Type"]))
			{
	            $strEnumFields = str_replace(array('enum','(',')',"'"),array(""),$arrResultRecord[0]['COLUMNS']["Type"]);           
			}
			else
			{
	            $strEnumFields = str_replace(array('enum','(',')',"'"),array(""),$arrResultRecord[0][0]["Type"]);           
			}
            $arrOptions = explode(",",$strEnumFields );

			if($field=='time_zone')
				$arrReturnVals["Timezone"] = "Timezone";

            while(list($key,$val) = each($arrOptions))
            {
                $arrReturnVals[$val]=$val;
            }
            return $arrReturnVals;
         
        }
 	  function makeArray()
      {
      	  	$arrMonths=array(1 =>'01',2 => '02',3 => '03',4 => '04',5 => '05',6 => '06',7 => '07',8 => '08',9 => '09',10 =>'10',11 =>'11',12 =>'12');
      	  	return($arrMonths);
      }
	 function makeYearArray()
      {
      		$intCurrentYear=date("Y");
      		$i=$intCurrentYear;
      		$j=$intCurrentYear+19;
      		//$arrYears[0]='Year';
      		while($i<$j)
      		{
      			$arrYears[$i]=$i;
      			$i++;
      		}
      	  	
      	  	return($arrYears);
      }
      
} 
?>